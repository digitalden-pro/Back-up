#!/bin/bash
##########################################################################################################################
#  Auto backup script by Orume Studios <support@orume.id>                                                                #
#                                                                                                                        #
#  Reselling or distributing this file, via any medium is strictly prohibited, you may only use it on your own machines! #
#  Proprietary and confidential                                                                                          #
#                                                                                                                        #
#  Contributors:                                                                                                         #
#  Yudha Abhista <xabhista19@gmail.com>                                                                                  #
#                                                                                                                        #
#  Link: https://orume.id                                                                                                #
#                                                                                                                        #
#  February 2, 2021                                                                                                      #
##########################################################################################################################

# Config
echo -n "Enter your conf path: "
read -r conf_path

archive_command="tar -zcvpf %temp_path%/%current_backup_date%/%file_name%.tgz"
upload_command="cp -rv "
data_folder_path="/var/lib/pterodactyl/volumes"
temp_path="/etc/auto-backup/temp"
cloud_path="/etc/auto-backup/cloud"
rclone_remote_name="autobackup"
backup_delay="1m"
machine_node_name="Orume Studios"
folder_only="yes"
ignore_file_format=".something"

# DETAILED LOGS - DISCORD WEBHOOK
logs_webhook_url=""

logs_temp_folder_not_exists="temp folder not exists @everyone"
logs_cloud_folder_not_exists="Cloud folder not exists @everyone"


logs_info_start="Starting to backup %file%"

logs_info_archive_success="Successfully archived %file%"
logs_info_archive_fail="Failed to archive %file%, error code: %error-code%"

logs_info_upload_success="Successfully uploaded %file%"
logs_info_upload_fail="Failed to upload %file%, error code: %error-code%"


# STATUS EMBED - DISCORD WEBHOOK
status_webhook_url=""
status_webhook_title="💾 Automatic Backup"

status_webhook_start_color="16776960"
status_webhook_start="[⌛] - Creating a backup for %machine_node_name%"
status_webhook_start_custom=""

status_webhook_success_color="65280"
status_webhook_success="[✅] - Successfully created a backup for %machine_node_name%"
status_webhook_success_custom=""

status_webhook_fail_color="15158332"
status_webhook_fail="[❌] - Failed to create a backup for %machine_node_name%"
status_webhook_fail_custom=""

backup_successful=0
backup_failed=0

load_conf() {
    config_file="${conf_path}/config.conf"
    lang_file="${conf_path}/lang.conf"

    
    if [ -f "${config_file}" ] && [ -n "${config_file}" ]; then
        . ${config_file}
    else
        autobackup_head
        echo "${config_file} not found."
        exit 1
    fi

    if [ -f "${lang_file}" ] && [ -n "${lang_file}" ]; then
        . ${lang_file}
        sleep 1s
    else
        autobackup_head
        echo "${lang_file} not found."
        exit 1
    fi
}

send_webhook_status() {
    status_description=$1
    status_color=$2

    if [ ! -z ${status_webhook_url} ]; then
        sleep 1s
        curl -X POST -H "Content-Type: application/json" -d "{\"embeds\":[{\"title\":\"$status_webhook_title\",\"url\":\"https://orume.id/\",\"description\":\"$status_description\",\"color\":\"$status_color\"}]}" ${status_webhook_url}
    fi
}

send_webhook_logs() {
    if [ ! -z ${logs_webhook_url} ]; then
        sleep 1s
        curl -X POST -H "Content-Type: application/json" -d "{\"content\": \"$1\"}" ${logs_webhook_url}
    fi
}

autobackup_head() {
    echo "Auto Backup version v1.3.3"
    echo "Copyright (C) 2021 - 2022, Orume Studios <support@orume.id>"
    echo
}

run_backup() {
    echo "Running backup..."

    if [ ! -z ${status_webhook_start_custom} ]; then
        echo "Sending custom status embed"
        default_status_embed=$(echo ${status_webhook_start_custom} | awk '{gsub(/%machine_node_name%/, "'"${machine_node_name}"'")}1')
        curl -X POST -H "Content-Type: application/json" -d "$default_status_embed" ${status_webhook_url}
    else
        echo "Sending default status embed"
        default_status_embed=$(echo ${status_webhook_start} | awk '{gsub(/%machine_node_name%/, "'"${machine_node_name}"'")}1')
        send_webhook_status "$default_status_embed" "$status_webhook_start_color"
    fi

    cd ${data_folder_path}
    current_backup_date=$(date +"%m-%d-%Y-%H:%S")
    for backupFileName in *; do
        send_webhook_logs "**~~[--------------------------------------------------------------------------------]~~**"

        start_log=$(echo ${logs_info_start} | awk '{gsub(/%file%/, "'"${backupFileName}"'")}1') 
        send_webhook_logs "$start_log"
        echo "Checking external temp folder.."
        mkdir -p ${temp_path}
        if [ ! -d "${temp_path}" ]; then
            send_webhook_logs "${logs_temp_folder_not_exists}"
            echo "External temp folder does not exists, please create the folder!"
            exit 1
        fi
        
        if [[ "$folder_only" == "yes" ]] || [[ "$folder_only" == "y" ]]; then
            if [[ -d "${backupFileName}" ]]; then
                echo "Backing up ${backupFileName}..."
            else
                echo "Skipping ${backupFileName}, not a directory.."
                send_webhook_logs "Skiping ${backupFileName}, not a directory.."
                continue
            fi
        else
            if [[ "$ignore_file_format" != "" ]]; then
                regexFiltered=$(echo "$ignore_file_format" | sed "s/\,/\|/g")
                regexFilter=".*\("$regexFiltered")$"

                if echo "${backupFileName}" | grep -E "$regexFilter"; then
                    echo "Backing up ${backupFileName}..."
                else
                    echo "Skipping ${backupFileName}, file format is ignored.."
                    send_webhook_logs "Skiping ${backupFileName}, file format is ignored.."
                    continue
                fi
            else 
                echo "Backing up ${backupFileName}..."
            fi
        fi


        echo "Creating a new folder from temp folder.."
        mkdir -p ${temp_path}/${current_backup_date}

        archive_eval_command=$(echo ${archive_command} | awk '{gsub(/%temp_path%/, "'"${temp_path}"'")}1' | awk '{gsub(/%current_backup_date%/, "'"${current_backup_date}"'")}1' | awk '{gsub(/%file_name%/, "'"${backupFileName}"'")}1' | awk '{gsub(/%data_folder_path%/, "'"${data_folder_path}"'")}1')
        echo "$archive_eval_command"

        sleep 5s

        echo "Archiving data..."
        if eval "$archive_eval_command"; then
            successful_archive_log=$(echo ${logs_info_archive_success} | awk '{gsub(/%file%/, "'"${backupFileName}"'")}1')
            send_webhook_logs "$successful_archive_log"
        else

            failed_archive_log=$(echo ${logs_info_archive_fail} | awk '{gsub(/%file%/, "'"${backupFileName}"'")}1' | awk '{gsub(/%error-code%/, "'"${?}"'")}1')
            send_webhook_logs "$failed_archive_log"
            backup_failed=$((++backup_failed))

            echo "Failed to archive data ${backupFileName}, error code: ${?}"
            rm -rfv ${temp_path}/${current_backup_date}
            continue
        fi


        upload_eval_command=$(echo ${upload_command} | awk '{gsub(/%temp_path%/, "'"${temp_path}"'")}1' | awk '{gsub(/%current_backup_date%/, "'"${current_backup_date}"'")}1' | awk '{gsub(/%file_name%/, "'"${backupFileName}"'")}1' | awk '{gsub(/%cloud_path%/, "'"${cloud_path}"'")}1' | awk '{gsub(/%rclone_remote_name%/, "'"${rclone_remote_name}"'")}1')
        echo "$upload_eval_command"

        echo "Uploading data to cloud..."
        if eval "$upload_eval_command"; then
            successful_upload_log=$(echo ${logs_info_upload_success} | awk '{gsub(/%file%/, "'"${backupFileName}"'")}1')
            send_webhook_logs "$successful_upload_log"
            backup_successful=$((++backup_successful))
        else
            failed_upload_log=$(echo ${logs_info_upload_fail} | awk '{gsub(/%file%/, "'"${backupFileName}"'")}1' | awk '{gsub(/%error-code%/, "'"${?}"'")}1')
            send_webhook_logs "$failed_upload_log"
            backup_failed=$((++backup_failed))
            echo "Failed to upload data ${backupFileName}, error code: ${?}"
            rm -rfv ${temp_path}/${current_backup_date}
            continue
        fi

        rm -rfv ${temp_path}/${current_backup_date}
        sleep ${backup_delay}
    done
}

load_conf
autobackup_head
run_backup

logs_webhook_complete=$(echo ${logs_info_completed} | awk '{gsub(/%backup_successful%/, "'"${backup_successful}"'")}1' | awk '{gsub(/%backup_failed%/, "'"${backup_failed}"'")}1')
send_webhook_logs "$logs_webhook_complete"
if [ ! -z ${status_webhook_success_custom} ]; then
    echo "Sending custom status embed"
    default_status_embed= $(echo ${status_webhook_success_custom} | awk '{gsub(/%machine_node_name%/, "'"${machine_node_name}"'")}1' | awk '{gsub(/%backup_successful%/, "'"${backup_successful}"'")}1' | awk '{gsub(/%backup_failed%/, "'"${backup_failed}"'")}1')
    curl -X POST -H  "Content-Type: application/json" -d "$default_status_embed" "$status_webhook_url"
else
    echo "Sending default status embed"
    default_status_embed=$(echo ${status_webhook_success} | awk '{gsub(/%machine_node_name%/, "'"${machine_node_name}"'")}1' | awk '{gsub(/%backup_successful%/, "'"${backup_successful}"'")}1' | awk '{gsub(/%backup_failed%/, "'"${backup_failed}"'")}1')
    send_webhook_status "$default_status_embed" "$status_webhook_success_color"
fi

exit 0
